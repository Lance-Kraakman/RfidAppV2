package com.example.rfidappv2.models

class Device {
    lateinit var id: String
    lateinit var uuid: String
    lateinit var name: String
    lateinit var x_location: String
    lateinit var y_location: String
    lateinit var station_id: String
    lateinit var temp: String
    lateinit var is_register: String
    lateinit var time_update_esp: String

}